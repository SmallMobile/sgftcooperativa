  --------------------------------------------------------------------
			   DigitalPersona

             DigitalPersona Platinum SDK 3.2.0 Delphi 6 Sample 

			
			    Readme File
			   
			   January 2006
				
   --------------------------------------------------------------------
	   (c) 2006 Digital Persona, Inc. All Rights Reserved. 


This document provides information how to utilize the DigitalPersona Platinum SDK from the Delphi 6 environment.


-------------------------
How to Use This Document
-------------------------

To view the Readme file on-screen in Windows Notepad, maximize the Notepad window. On the Edit menu, click Word Wrap. To print the Readme file, open it in Notepad or another word processor, and then use the Print command on the File menu.


---------
CONTENTS
---------
1.	Type Libraries 

2.	Sample Code


------------------
1. Type Libraries 
------------------
After DigitalPersona Platinum SDK is installed on the computer, import its type libraries in Delphi 6:
DigitalPersona Platinum SDK Engine 3.1.0 (Version 1.1)
DigitalPersona Platinum SDK Operations 3.1.0 (Version 1.1)


----------------
2. Sample Code
----------------
The SDKOps sample provides you with a Delphi 6 project which illustrates how to implement the fingerprint registration and fingerprint verification functionality. 
The sample code was compiled for Delphi 6. You may experience minor incompatibility problems when using it from Delphi5 or Delphi 7. In order to compile this sample code under Delphi 5 or Delphi 7 some modifications are required.



